import tkinter as tk

def click(event):
    current = entry.get()
    button_text = event.widget.cget("text")
    
    if button_text == "=":
        try:
            result = eval(current)
            entry.delete(0, tk.END)
            entry.insert(0, str(result))
        except:
            entry.delete(0, tk.END)
            entry.insert(0, "Error")
    elif button_text == "C":
        entry.delete(0, tk.END)
    else:
        entry.insert(tk.END, button_text)

# for main window
root = tk.Tk()
root.title("CALCULATOR USING TKINTER")
root.geometry("300x400")
root.config(bg="gray")  # bg color- main window


entry = tk.Entry(
    root, font="Arial 22", borderwidth=4, relief="solid", justify="right",
    bg="white", fg="black")
entry.pack(fill=tk.BOTH, ipadx=8, ipady=15, padx=10, pady=10)

# for Button layout
button_texts = [
    ["7", "8", "9", "/"],
    ["4", "5", "6", "*"],
    ["1", "2", "3", "-"],
    ["C", "0", "=", "+"]
]

for row in button_texts:
    frame = tk.Frame(root, bg="gray")  # Match bg of main window
    frame.pack(expand=True, fill="both")
    for text in row:
        btn = tk.Button(
            frame, text=text, font="Arial 18", borderwidth=1,
            bg="skyblue", fg="black", activebackground="deepskyblue"
        )
        btn.pack(side="left", expand=True, fill="both")
        btn.bind("<Button-1>", click)

# Run app
root.mainloop()
